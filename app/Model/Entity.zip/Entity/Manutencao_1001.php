<?php

namespace App\Model\Entity;

use WilliamCosta\DatabaseManager\Database;

class Manutencao
{
    public $codmanutencao;
    public $codcliente;
    public $descricao;
    public $tipo;
    public $tiposervico;
    public $entrada;
    public $saida;
    public $custo;
    public $dtmanutencao;
    public $dtencerrado;

    public static function buscar($where = null, $order = null, $limit = null, $filds = '*')
    {
        return (new Database('manutencao'))->select($where, $order, $limit, $filds);
    }

    public static function buscarJoin($where = null, $order = null, $limit = null, $filds = '*')
    {
        return (new Database('manutencao left'))->selectJoin($where, $order, $limit, $filds, 'cadprod', 'manutencao.entrada = cadprod.codprod');
    }

    public static function buscarJoinPag($where = null, $order = null, $limit = null, $filds = '*')
    {
        return (new Database('manutencao left'))->selectJoin($where, $order, $limit, $filds, 'manutencaopagamentos', 'manutencaopagamentos.codmanutencao = manutencao.codmanutencao');
    }


    public static function finalizar()
    {
        $dtencerrado = Date('Y-m-d H:i');
        $obDatabase = new Database('manutencao');
        $success = $obDatabase->update('dtencerrado is null',
            [
                'dtencerrado' => $dtencerrado,
            ]);
    }


    public function atualizar()
    {

        $obDatabase = new Database('manutencao');
        $success = $obDatabase->update('codprod =' . $this->codmanutencao,
            [
                'descricao' => $this->descricao,
                'tipo' => $this->tipo,
                'tiposervico' => $this->tiposervico,
                'entrada' => $this->entrada,
                'saida' => $this->saida,
                'custo' => $this->custo,
            ]);
    }

    public function cadastrar()
    {
        $this->dtmanutencao = Date('Y-m-d H:i');
        $obDatabase = new Database('manutencao');
        $success = $obDatabase->insert(            [
            'descricao' => $this->descricao,
            'tipo' => $this->tipo,
            'tiposervico' => $this->tiposervico,
            'entrada' => $this->entrada,
            'saida' => $this->saida,
            'custo' => $this->custo,
            'dtmanutencao' => $this->dtmanutencao,
        ]);
        return $success;
    }

    public function deletar(){
        $obDatabase = new Database('manutencao');
        $success = $obDatabase->delete('codmanutencao = '.$this->codmanutencao);
    }

}